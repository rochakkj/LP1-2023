package modelo;

public class Bolsa {
	
	private Empresa empresaResponsavel;
	
	
}
